<?php


ini_set('memory_limit', '-1');
ini_set('max_execution_time', 300); //300 seconds = 5 minutes
$server = "localhost";
$username = "root";
$password = "";
$dbname = "datathon";

header("content-type: text/html;charset=utf-8");

$connection = new mysqli('127.0.0.1', $username, $password, $dbname);
$connection->set_charset("utf8");



if (mysqli_connect_errno()) {
    printf("Connect failed: %s\n", mysqli_connect_error());
    exit();
}

$tableName = 'products';

//$result = $connection->query("SELECT name FROM $tableName");
//$array = $result->fetch_assoc();
$result = $connection->query("SELECT fk_product_name,(SELECT name from categories where id = fk_category_id) FROM products_stores");
$a = $result->fetch_all();



//echo("$a");


echo json_encode($a);

?>